// chrome.runtime.onConnect.addListener(
//     function(port)
//     {
//     	console.assert(port.name == "supreme2");
//     	port.onMessage.addListener(function(msg) {
//     		console.log(msg);
// 	    	//window.alert("got to background.js");
// 	        if(msg.enable)
// 	        {
// 	          	$("[name=commit]").click();

// 				setTimeout(function() {
// 					//window.alert("trying to go to checkout page");
// 					chrome.extension.sendMessage({action: "start", url: "http://www.supremenewyork.com/checkout", enable: true});

// 				}, 1000);
// 	        }
//     	});
    	
//         //else if(request.action == "checkout") {
//         //	chrome.tabs.update({url: request.url});
//         //}
//     }
// );
chrome.extension.sendMessage({action: "getDisabled"}, function(response) {
	console.log(response);
	if(response.disable == false) {
		chrome.storage.local.get('size', function(result) {
	    	console.log(result.size);
	    	if($("#size")[0].type !== "hidden") {
	    		var val = "";
		    	for (var i = 0; i < $("#size")[0].options.length; i++) {
		    		if($("#size")[0].options[i].text === result.size) {
		    			val = $("#size")[0].options[i].value;
		    		}
		    	}
		    	$("#size").val(val);
	    	}
	    	$("[name=commit]").click();
			setTimeout(function() {
				//window.alert("trying to go to checkout page");
				chrome.extension.sendMessage({action: "start", url: "http://www.supremenewyork.com/checkout"});

			}, 1000);
	    });
		//console.log(size);
		 
	} 
});

	

   


//chrome.extension.sendMessage({action: "start", url: "http://www.supremenewyork.com/checkout"});

//chrome.runtime.sendMessage({action: "start", url:"http://www.supremenewyork.com/checkout"}, function(response) {
//});

